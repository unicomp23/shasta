import {logLevel} from "kafkajs";

export const kafkaLogLevel = logLevel.NOTHING;
